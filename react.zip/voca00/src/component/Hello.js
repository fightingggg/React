import { useState } from 'react';
import World from "./World";
import styles from "./Hello.module.css";
import UserName from "./UserName";

export default function Hello(props){
   const [name, setName] = useState("Mike");

   function changeName() {
    if (name === "Mike") {
      setName("Jane");
    } else {
      setName("Mike");
    }
  }
  
    return (
       <div className={styles.main}>
        <h1 className={styles.header}>state</h1>

        {/* <h2 id="name">
            {name} (
            {props.age},{" "}
            {props.age < 20 ? "미성년자" : "성인"})
        </h2> */}

                <h2 id="name">
                {name} ({props.age},{" "}
                {function() {
                    if (props.age < 20) {
                    return "미성년자";
                    } else {
                    return "성인";
                    }
                }()})
                </h2>
           


        <UserName name={name + '입니다'}  />

        <button onClick={changeName}> Change </button>
      </div>
    );
}




// import { useState } from 'react';
// import World from "./World";
// import styles from "./Hello.module.css"

// export default function Hello(props){
//    const [name, setName] = useState("Mike");

//    function changeName(){
//     const newName = name === "Mike" ? "Jane" : "Mike";
//     setName(newName);
//    }

//     return (
//        <div className={styles.main}>
//         <h1 className={styles.header}>state</h1>

//         <h2 id="name">{name}({props.age} {props.age < 20 ? '미성년자' : '성인'})</h2>  // 20살 미만이면 '미성년자', 그렇지 않으면 '성인' 출력
//         <button onClick={changeName}> Change </button>

//         </div>
//     );
// }


// function changeName(){
//     const newName = name === "Mike" ? "Jane" : "Mike";
//     setName(newName);
//    }