import { useState } from 'react';
import World from "./World";
import styles from "./Hello.module.css"

export default function Hello(){
    const [text, setText] = useState('');

    function showName(){
        setText('Mike');
    }

    function showAge(age){
        setText(age);
    }

    function showText(txt){
        console.log(txt);
        setText(txt);
    }

    return (
        <div>
            <h1 >Hello</h1>
            <button onClick={showName}> Show name </button>
            <button
                onClick={() => {
                    showAge(30)
                }}
                >
                    Show age
                </button>
                
            <input
                type="text"
                value={text}
                onChange={e => {
                    const txt = e.target.value;
                    showText(txt);
                }}
            />
        </div>
    );
}
