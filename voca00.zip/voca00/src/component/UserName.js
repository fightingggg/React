export default function UserName({name}){
    return <p>Hello, {name} </p>
}