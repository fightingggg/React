// import dummy from "../db/data.json";
import {useParams} from "react-router-dom";
import {useEffect,useState} from "react";
import Word from "./Word";


export default function Day() {
const {day} = useParams(); // /2, /1 , /3 쓰면 작동이 됨 sts                , jsx 문법
// const wordList = dummy.words.filter(word => word.day === Number(day));
const[words,setWords] = useState([]);

useEffect(()=> {
    fetch(`http://localhost:3002/words?day=${day}`)
    // 데이터는 3002, 화면동작은 3000,       javascript 문법
.then(res=> {
    return res.json();
}).then(data=>{
    setWords(data);
})
},[day]);

return (
<>
<h2>Day {day}</h2>
<table>
<tbody>
    {
        words.map(word=>(
            <Word word={word} key={word.id}/>
        ))
    }



</tbody>
</table>
</>
);
}