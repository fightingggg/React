import { useState } from "react"; // React의 useState 훅을 가져옵니다. 이를 통해 컴포넌트 내부에 상태를 만들 수 있습니다.

export default function Word({ word: w }) {
  
  const [word, setWord] = useState(w); // word라는 상태를 생성하고 초기값으로 props로 받은 word를 설정합니다.
  const [isShow, setIsShow] = useState(false); // isShow라는 상태를 생성하고 초기값으로 false를 설정합니다.
  const [isDone, setIsDone] = useState(word.isDone); // isDone이라는 상태를 생성하고 초기값으로 word의 isDone 값을 설정합니다.

  // isShow 상태를 토글하는 함수입니다.
  function toggleShow() {
    setIsShow(!isShow);
  }

  // isDone 상태를 변경하고 해당 상태를 서버에 업데이트하는 함수입니다.
  function toggleDone() {
    fetch(`http://localhost:3002/words/${word.id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ...word,
        isDone: !isDone,
      }),
    }).then(res => {
      if (res.ok) {
        setIsDone(!isDone); // 응답이 성공하면 isDone 상태를 토글합니다.
      }
    });
  }

  // 단어를 삭제하는 함수입니다.
  function del() {
    if (window.confirm("삭제 하시겠습니까?")) {
      fetch(`http://localhost:3002/words/${word.id}`, {
        method: "DELETE",
      }).then(res => {
        if (res.ok) {
          setWord({ id: 0 }); // 응답이 성공하면 word 상태를 초기화합니다.
        }
      });
    }
  }

  // word가 없으면 아무것도 렌더링하지 않습니다.
  if (word.id === 0) {
    return null;
  }

  // 아래는 JSX 문법으로 작성된 컴포넌트의 렌더링 부분입니다.
  return (
    <tr className={isDone ? "off" : ""}>
      <td>
        <input type="checkbox" checked={isDone} onChange={toggleDone} /> {/* 체크박스. 체크 상태는 isDone이며, 클릭 시 toggleDone 함수를 실행합니다. */}
      </td>
      <td>{word.eng}</td> {/* 영어 단어를 렌더링합니다. */}
      <td>{isShow && word.kor}</td> {/* 한국어 뜻을 렌더링합니다. isShow가 true일 때만 렌더링됩니다. */}
      <td>
        <button onClick={toggleShow}>뜻 {isShow ? "숨기기" : "보기"}</button> {/* '뜻 보기/숨기기' 버튼. 클릭 시 toggleShow 함수를 실행합니다. */}
        <button onClick={del} className="btn_del"> {/* '삭제' 버튼. 클릭 시 del 함수를 실행합니다. */}
          삭제
        </button>
      </td>
    </tr>
  );
}
